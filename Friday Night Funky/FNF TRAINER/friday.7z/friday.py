import pygame
import random
import json
import os

# Inicialização do Pygame
pygame.init()

# Configurações do jogo
config_path = "config.json"
if not os.path.exists(config_path):
    config = {
        "note_spawn_rate": 30,
        "note_speed": 5,
        "fps_limit": 60,
        "health_max": 100,
        "health_gain": 1,
        "health_loss": 5,
        "botplay_level": 1
    }
    with open(config_path, "w") as config_file:
        json.dump(config, config_file, indent=4)
else:
    with open(config_path, "r") as config_file:
        config = json.load(config_file)

# Configurações da tela
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("FNF Trainer")
icon = pygame.image.load("assets/icon.ico")
pygame.display.set_icon(icon)
pygame.mouse.set_visible(False)

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Variável para controle do modo tela cheia
fullscreen = False

def toggle_fullscreen():
    global fullscreen, screen, WIDTH, HEIGHT
    fullscreen = not fullscreen
    if fullscreen:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
    WIDTH, HEIGHT = screen.get_size()
    resize_assets()
    update_positions()

def resize_assets():
    global arrow_images, pressed_arrow_images, boy_images, arrow_size, boy_size
    arrow_size = WIDTH // 16  # Ajusta o tamanho das setas conforme a tela
    boy_size = WIDTH // 8  # Ajusta o tamanho do personagem
    
    arrow_images = {key: pygame.transform.scale(pygame.image.load(f"assets/{name}.png"), (arrow_size, arrow_size)) for key, name in keys.items()}
    pressed_arrow_images = {key: pygame.transform.scale(pygame.image.load(f"assets/{name}_pressed.png"), (arrow_size, arrow_size)) for key, name in keys.items()}
    
    # Ajuste para carregar as imagens do personagem corretamente
    boy_images = {
        pygame.K_d: pygame.transform.scale(pygame.image.load("assets/boy_left_arrow.png"), (boy_size, boy_size)),
        pygame.K_f: pygame.transform.scale(pygame.image.load("assets/boy_down_arrow.png"), (boy_size, boy_size)),
        pygame.K_j: pygame.transform.scale(pygame.image.load("assets/boy_up_arrow.png"), (boy_size, boy_size)),
        pygame.K_k: pygame.transform.scale(pygame.image.load("assets/boy_right_arrow.png"), (boy_size, boy_size)),
        "idle": pygame.transform.scale(pygame.image.load("assets/boy_idle.png"), (boy_size, boy_size))
    }

def update_positions():
    global arrow_positions, boy_x, boy_y, fixed_arrows
    arrow_positions = {key: (WIDTH // 2 - 200 + (i * 100), HEIGHT - 140) for i, key in enumerate(keys)}
    boy_x, boy_y = 20, HEIGHT - (boy_size + 20)
    fixed_arrows = {key: (x, HEIGHT - 140) for key, (x, _) in arrow_positions.items()}

# Configurações das setas
keys = {
    pygame.K_d: "left_arrow",
    pygame.K_f: "down_arrow",
    pygame.K_j: "up_arrow",
    pygame.K_k: "right_arrow"
}

# Inicializa assets
arrow_images = {}
pressed_arrow_images = {}
boy_images = {}
resize_assets()
update_positions()

# Variáveis do jogo
health = config["health_max"]
score = 0
erros = 0
accuracy = 100.0
botplay = False
arrows = []
pressed_keys = {key: False for key in keys}
current_boy_image = boy_images["idle"]

# Definindo as taxas de erro por nível
error_rates = {
    1: 0.75,  # 75% de chance de erro no nível 1
    2: 0.60,  # 60% de chance de erro no nível 2
    3: 0.45,  # 45% de chance de erro no nível 3
    4: 0.30,  # 30% de chance de erro no nível 4
    5: 0.15,  # 15% de chance de erro no nível 5
    6: 0.05,  # 5% de chance de erro no nível 6
    7: 0.02,  # 2% de chance de erro no nível 7
    8: 0.00   # 0% de chance de erro no nível 8
}

class Arrow:
    def __init__(self, key):
        self.key = key
        self.x, _ = arrow_positions[key]
        self.y = 0
        self.image = arrow_images[key]

    def move(self):
        self.y += config["note_speed"]

    def draw(self):
        screen.blit(self.image, (self.x, self.y))

def draw_fixed_arrows():
    for key, pos in fixed_arrows.items():
        screen.blit(pressed_arrow_images[key] if pressed_keys[key] else arrow_images[key], pos)

def draw_arrows():
    for arrow in arrows:
        arrow.draw()

def draw_boy():
    screen.blit(current_boy_image, (boy_x, boy_y))

def draw_hud():
    font = pygame.font.Font(None, 36)
    screen.blit(font.render(f"Health: {health}", True, WHITE), (10, 10))
    screen.blit(font.render(f"Score: {score}", True, WHITE), (10, 50))
    screen.blit(font.render(f"Errors: {erros}", True, WHITE), (10, 90))
    screen.blit(font.render(f"Accuracy: {accuracy:.1f}%", True, WHITE), (10, 130))
    screen.blit(font.render(f"Botplay Level: {config['botplay_level']}", True, WHITE), (10, 170))

def botplay_logic():
    global health, erros, score, accuracy, current_boy_image
    for arrow in arrows[:]:
        if arrow.y >= HEIGHT - 140:
            # Obter a taxa de erro com base no nível
            error_chance = error_rates.get(config["botplay_level"], 0.75)  # Padrão para nível 1
            if random.random() > error_chance:  # Ajuste a chance de erro
                pressed_keys[arrow.key] = True
                current_boy_image = boy_images[arrow.key]
                pygame.time.set_timer(pygame.USEREVENT + 1, 150, True)
                score += 1
                accuracy = min(100.0, accuracy + 0.2)
                health = min(config["health_max"], health + config["health_gain"])
            else:
                erros += 1
                health -= config["health_loss"]
                accuracy = max(90.0, accuracy - 2)
            arrows.remove(arrow)

def spawn_arrow():
    key = random.choice(list(keys.keys()))
    arrows.append(Arrow(key))

# Loop principal do jogo
clock = pygame.time.Clock()
running = True
while running:
    screen.fill(BLACK)
    draw_fixed_arrows()
    draw_arrows()
    draw_boy()
    draw_hud()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key in keys:
                pressed_keys[event.key] = True
                current_boy_image = boy_images[event.key]
        if event.type == pygame.KEYUP:
            if event.key in keys:
                pressed_keys[event.key] = False
                current_boy_image = boy_images["idle"]
        if event.type == pygame.USEREVENT + 1:
            current_boy_image = boy_images["idle"]
        if event.type == pygame.USEREVENT:
            spawn_arrow()

    if botplay:
        botplay_logic()

    for arrow in arrows:
        arrow.move()

    pygame.display.flip()
    clock.tick(config["fps_limit"])

pygame.quit()